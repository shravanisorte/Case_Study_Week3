# Databricks notebook source
print("hello")

# COMMAND ----------

# Replace with your actual values
storage_account_name = "transaction3"
storage_account_key = "rtLJxvX2x6e1LYiN/xtZ5DgGKw02iQbEh1pYQOh5RL+Od9lox6Q2HJIjY9y9FTXUmUr3xNQVXcyY+ASte/VVPQ=="
container_name = "casestudy3"
file_path = "transactions.csv"  # Or full folder path if inside subdirectory

# Set the storage account key in Spark configuration
spark.conf.set(
    f"fs.azure.account.key.{storage_account_name}.blob.core.windows.net",
    storage_account_key
)

# Read CSV from Azure Blob Storage
df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load(f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{file_path}")

display(df)


# COMMAND ----------

from pyspark.sql.functions import split, col
from pyspark.sql.types import DoubleType

# Read from Kafka Event Hub
df_kafka = spark.readStream.format("kafka") \
    .option("kafka.bootstrap.servers", "pos-transactions.servicebus.windows.net:9093") \
    .option("subscribe", "pos-transactions") \
    .option("startingOffsets", "earliest") \
    .option("kafka.security.protocol", "SASL_SSL") \
    .option("kafka.sasl.mechanism", "PLAIN") \
    .option("kafka.sasl.jaas.config", """
        org.apache.kafka.common.security.plain.PlainLoginModule required username="$ConnectionString" password="Endpoint=sb://pos-transactions.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=E6NjJn5grdKJ1BRbighozDsR2lChen7uC+AEhBUboKM=";
    """) \
    .load()

# Convert Kafka value (binary) to string
df_string = df_kafka.selectExpr("CAST(value AS STRING) as csv_line")


# COMMAND ----------

display(df_string)


# COMMAND ----------

display(df)

# COMMAND ----------

file_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/transactions.csv"

df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load(file_path)

# COMMAND ----------

display(df)

# COMMAND ----------

sas_token = "sp=racwl&st=2025-08-03T11:50:18Z&se=2025-08-03T20:05:18Z&spr=https&sv=2024-11-04&sr=c&sig=cKObwSwUWGLgvWHNSO5IOpKkhuKg0G2P%2BpCIiZiMxUE%3D"

spark.conf.set(
    "fs.azure.sas.casestudy3.transaction3.blob.core.windows.net",
    sas_token
)

# COMMAND ----------

bronze_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/bronze/transactions"


# COMMAND ----------

bronze_dbfs_path = "dbfs:/mnt/bronze/transaction"

df.write.format("delta").mode("overwrite").save(bronze_dbfs_path)

spark.sql(f"""
CREATE TABLE IF NOT EXISTS bronze_transactions
USING DELTA
LOCATION '{bronze_dbfs_path}'
""")


# COMMAND ----------

display(spark.read.format("delta").load(bronze_dbfs_path))


# COMMAND ----------

dbutils.fs.ls(bronze_dbfs_path)


# COMMAND ----------

bronze_dbfs_path = "dbfs:/mnt/bronze/transaction"

df_bronze = spark.read.format("delta").load(bronze_dbfs_path)
display(df_bronze)


# COMMAND ----------

from pyspark.sql.functions import col

df_silver = (
    df_bronze.dropDuplicates(["transaction_id"])
             .filter(col("amount").isNotNull())
             .filter(col("timestamp").isNotNull())
)

display(df_silver)


# COMMAND ----------

silver_dbfs_path = "dbfs:/mnt/silver/transaction"

df_silver.write.format("delta").mode("overwrite").save(silver_dbfs_path)

spark.sql(f"""
CREATE TABLE IF NOT EXISTS silver_transactions
USING DELTA
LOCATION '{silver_dbfs_path}'
""")


# COMMAND ----------

display(spark.read.format("delta").load(silver_dbfs_path))


# COMMAND ----------

silver_dbfs_path = "dbfs:/mnt/silver/transaction"

df_silver = spark.read.format("delta").load(silver_dbfs_path)
display(df_silver)


# COMMAND ----------

df_gold = (
    df_silver.groupBy("region")
             .sum("amount")
             .withColumnRenamed("sum(amount)", "total_sales")
)

display(df_gold)


# COMMAND ----------

gold_dbfs_path = "dbfs:/mnt/gold/transaction"

df_gold.write.format("delta").mode("overwrite").save(gold_dbfs_path)

spark.sql(f"""
CREATE TABLE IF NOT EXISTS gold_transactions
USING DELTA
LOCATION '{gold_dbfs_path}'
""")


# COMMAND ----------

display(spark.read.format("delta").load(gold_dbfs_path))


# COMMAND ----------

dbutils.fs.ls("dbfs:/mnt/bronze/transaction")
dbutils.fs.ls("dbfs:/mnt/silver/transaction")
dbutils.fs.ls("dbfs:/mnt/gold/transaction")


# COMMAND ----------

# Source paths in DBFS
bronze_dbfs_path = "dbfs:/mnt/bronze/transaction"
silver_dbfs_path = "dbfs:/mnt/silver/transaction"
gold_dbfs_path = "dbfs:/mnt/gold/transaction"

# Destination paths in Azure Blob
bronze_blob_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/bronze/transaction"
silver_blob_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/silver/transaction"
gold_blob_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/gold/transaction"


# COMMAND ----------

dbutils.fs.cp(bronze_dbfs_path, bronze_blob_path, recurse=True)
dbutils.fs.cp(silver_dbfs_path, silver_blob_path, recurse=True)
dbutils.fs.cp(gold_dbfs_path, gold_blob_path, recurse=True)


# COMMAND ----------

sas_token = "sp=racwdt&st=2025-08-03T12:25:17Z&se=2025-08-03T20:40:17Z&spr=https&sv=2024-11-04&sr=b&sig=G%2FrvTh4wMoRHDLO1MclV9U36mpArzr93Klv6JS2%2FmRk%3D"

spark.conf.set(
    "fs.azure.sas.casestudy3.transaction3.blob.core.windows.net",
    sas_token
)


# COMMAND ----------

# DBFS source paths
bronze_dbfs_path = "dbfs:/mnt/bronze/transaction"
silver_dbfs_path = "dbfs:/mnt/silver/transaction"
gold_dbfs_path = "dbfs:/mnt/gold/transaction"

# Azure Blob destination paths
bronze_blob_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/bronze/transaction"
silver_blob_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/silver/transaction"
gold_blob_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/gold/transaction"


# COMMAND ----------

dbutils.fs.cp(bronze_dbfs_path, bronze_blob_path, recurse=True)
dbutils.fs.cp(silver_dbfs_path, silver_blob_path, recurse=True)
dbutils.fs.cp(gold_dbfs_path, gold_blob_path, recurse=True)


# COMMAND ----------

# Your SAS token (without the leading '?')
sas_token = "sp=racwt&st=2025-08-03T12:04:43Z&se=2025-08-03T20:19:43Z&spr=https&sv=2024-11-04&sr=b&sig=dFxl3tPw3Dcppjmrzns4u8244ChiZyzWwRiUJ0VS0l0%3D"

# Azure Blob destination path
bronze_blob_path = f"wasbs://casestudy3@transaction.blob.core.windows.net/delta/bronze/transaction" + "?" + "{sas_token}"
        
# Copy from DBFS to Azure Blob
dbutils.fs.cp("dbfs:/mnt/bronze/transactions", bronze_blob_path, recurse=True)


# COMMAND ----------

bronze_path = f"wasbs://casestudy3@transaction3.blob.core.windows.net/delta/bronze/transactions"
bronze_path = "wasbs://casestudy3@transaction3.blob.core.windows.net/delta/bronze/transactions"


df.write.format("delta").mode("overwrite").save(bronze_path)

# COMMAND ----------

# MAGIC %pip install great_expectations
# MAGIC

# COMMAND ----------

silver_path = "dbfs:/mnt/silver/transaction"
gold_path = "dbfs:/mnt/gold/transaction"

df_silver = spark.read.format("delta").load(silver_path)
df_gold = spark.read.format("delta").load(gold_path)


# COMMAND ----------

import great_expectations as gx

# Create temporary Data Context
context = gx.get_context(mode="ephemeral")


# COMMAND ----------

silver_path = "dbfs:/mnt/silver/transaction"
gold_path = "dbfs:/mnt/gold/transaction"

df_silver = spark.read.format("delta").load(silver_path)
df_gold = spark.read.format("delta").load(gold_path)


# COMMAND ----------

from pyspark.sql.functions import col

# Silver checks
null_txn_ids = df_silver.filter(col("transaction_id").isNull()).count()
invalid_amounts = df_silver.filter((col("amount") < 0) | (col("amount") > 100000)).count()
invalid_regions = df_silver.filter(~col("region").isin("West", "North", "South", "East")).count()

print(f"Silver Null transaction_id: {null_txn_ids}")
print(f"Silver Invalid amounts: {invalid_amounts}")
print(f"Silver Invalid regions: {invalid_regions}")

# Gold checks
null_regions = df_gold.filter(col("region").isNull()).count()
invalid_sales = df_gold.filter((col("total_sales") < 0) | (col("total_sales") > 1e9)).count()

print(f"Gold Null regions: {null_regions}")
print(f"Gold Invalid total_sales: {invalid_sales}")


# COMMAND ----------

if null_txn_ids == 0 and invalid_amounts == 0 and invalid_regions == 0 and \
   null_regions == 0 and invalid_sales == 0:
    print("Data Validation Passed")
else:
    print(" Data Validation Failed — Check Issues Above")


# COMMAND ----------

import great_expectations as ge

ge_silver = ge.dataset.SparkDFDataset(df_silver)
ge_gold = ge.dataset.SparkDFDataset(df_gold)


# COMMAND ----------

# Export Silver table to CSV
spark.read.format("delta").load("dbfs:/mnt/silver/transaction") \
    .toPandas().to_csv("/dbfs/FileStore/silver.csv", index=False)

# Export Gold table to CSV
spark.read.format("delta").load("dbfs:/mnt/gold/transaction") \
    .toPandas().to_csv("/dbfs/FileStore/gold.csv", index=False)


# COMMAND ----------

# MAGIC %pip install great_expectations
# MAGIC

# COMMAND ----------

# MAGIC %restart_python
# MAGIC

# COMMAND ----------

import pandas as pd

silver_df = pd.read_csv("/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in/silver.csv")
gold_df = pd.read_csv("/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in/gold.csv")


# COMMAND ----------

import great_expectations as ge

ge_silver = ge.dataset.PandasDataset(silver_df)
ge_gold = ge.dataset.PandasDataset(gold_df)


# COMMAND ----------

# MAGIC %pip install great_expectations
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()


# COMMAND ----------

# MAGIC %pip install great_expectations==0.15.50
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()


# COMMAND ----------

import great_expectations as ge
import pandas as pd

silver_df = pd.read_csv("/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in/silver.csv")
gold_df = pd.read_csv("/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in/gold.csv")

ge_silver = ge.dataset.PandasDataset(silver_df)
ge_gold = ge.dataset.PandasDataset(gold_df)


# COMMAND ----------

# Silver validations
ge_silver.expect_column_values_to_not_be_null("transaction_id")
ge_silver.expect_column_values_to_be_between("amount", min_value=0, max_value=100000)
ge_silver.expect_column_values_to_be_in_set("region", ["West", "North", "South", "East"])

# Gold validations
ge_gold.expect_column_values_to_not_be_null("region")
ge_gold.expect_column_values_to_be_between("total_sales", min_value=0, max_value=1e9)


# COMMAND ----------

silver_results = ge_silver.validate()
gold_results = ge_gold.validate()

print("Silver Validation Results:", silver_results)
print("Gold Validation Results:", gold_results)


# COMMAND ----------

import json

# Convert Great Expectations results to plain Python dict
silver_results_dict = silver_results.to_json_dict()
gold_results_dict = gold_results.to_json_dict()

# Paths where your CSVs are saved
base_path = "/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in"

# Save Silver validation results
with open(f"{base_path}/silver_validation.json", "w") as f:
    json.dump(silver_results_dict, f, indent=4)

# Save Gold validation results
with open(f"{base_path}/gold_validation.json", "w") as f:
    json.dump(gold_results_dict, f, indent=4)

print("Validation results saved successfully.")


# COMMAND ----------

from datetime import datetime

silver_summary = [{
    "layer": "silver",
    "success": silver_results["success"],
    "timestamp": datetime.now().isoformat()
}]

gold_summary = [{
    "layer": "gold",
    "success": gold_results["success"],
    "timestamp": datetime.now().isoformat()
}]

spark.createDataFrame(silver_summary) \
    .write.mode("overwrite").format("delta") \
    .save("/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in/validation_results/silver_summary")

spark.createDataFrame(gold_summary) \
    .write.mode("overwrite").format("delta") \
    .save("/dbfs/FileStore/shared_uploads/traininguser4@gisul.co.in/validation_results/gold_summary")


# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/shared_uploads/traininguser4@gisul.co.in/")


# COMMAND ----------



# COMMAND ----------

